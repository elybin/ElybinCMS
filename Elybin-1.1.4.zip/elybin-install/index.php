<?php
/**
 * The main script of installer.
 *
 * @package   Elybin CMS (www.elybin.com) - Open Source Content Management System
 * @author		Khakim A <kim@elybin.com>
 * @since 		Elybin 1.0.0
 */

/**  include function */
require("inc/install.func.php");

/**  Starting setup */
lets_start_the_setup();
