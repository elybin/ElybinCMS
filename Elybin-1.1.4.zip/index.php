<?php
/**
 * The main script of homepage.
 *
 * @package   Elybin CMS (www.elybin.com) - Open Source Content Management System
 * @author		Khakim A <kim@elybin.com>
 * @since 		Elybin 1.0.0
 */

/** We need the first material and invisible dark matter */
require_once('./elybin-core/elybin-function.php');

/**  And this is the begining, BigBang! */
bigbang();
?>
