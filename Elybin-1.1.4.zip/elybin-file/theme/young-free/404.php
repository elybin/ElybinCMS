<?php
/**
 * The template for displaying not found page.
 *
 * @package Elybin
 * @subpackage YoungFree
 * @since YoungFree 1.1
 */
get_header(); ?>
<!-- Main Content -->
<div class="container" style="margin-top:90px ;margin-bottom:250px">
  <div class="row">
    <div class="col-md-12">

      <div class="col-md-12 col-sm-12">
        <h1>404 Not Found</h1>
      </div>
    </div>
  </div>
</div>
<?php get_footer() ?>
