<?php
/**
 * Message printed while maintenance.
 *
 * @package   Elybin CMS (www.elybin.com) - Open Source Content Management System
 * @author		Khakim A <kim@elybin.com>
 * @since 		Elybin 1.1.4
 */

_e('Ready for upgrading to newer version, please login as Administrator.');
