<?php
/*
	Plugin Name: Hello World
	Plugin URI: http://store.elybin.com/apps/hello_world
	Plugin Type: Application
	Description: Simple application for reference. <br/>Access the front end at http://yourweb.com/?apps=hello_world&apps_page=test
	Version: 1.0
	Author: Kim@Elybin
	Author URI: http://kim.elybin.com/
	Text Domain: hello_world
	Domain Path: /lang
	License: GPLv2 or later
 */ ?>

<h1><?php _e('Hello!') ?></h1>
